
# Force push your modifications
echo "Force push your modifications"
echo "====================================="
echo "push origin master --force"
echo "====================================="
# git push origin master --force

# Cleanup and reclaiming space
echo "Cleanup and reclaiming space"
rm -rf .git/refs/original/
git reflog expire --expire=now --all

echo "====================================="
echo "gc --prune=now"
echo "====================================="
git gc --prune=now

echo "====================================="
echo "gc --aggressive --prune=now"
echo "====================================="
git gc --aggressive --prune=now
